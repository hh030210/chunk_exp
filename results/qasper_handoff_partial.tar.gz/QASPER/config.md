# QASPER 配置（进行中）

- 原始输入：`/home/humq/chunk_code/data/external/qasper/v0.3/test_release_extracted_v1/qasper-test-v0.3.json`
- SHA-256：`6e29ad410e6e39aa1936017fb965b30a20eb2e7751997f55b97c9d281aa884e5`
- split：官方 test 全部 416 篇论文、1451 个问题
- 规范化：只使用 full_text；保留 section_name 与 paragraphs 的原始字符串，以两个换行符按原始顺序连接；空标题省略；paragraph 索引从零开始。
- B0 tokenizer：`Qwen/Qwen3.5-9B` revision `c202236235762e1c871ad0ccb60c8ee5ba337b9a` 的 tokenizer.json；分别运行 256、512、1024 tokens，overlap=0；确定性切分，seed 不适用。
- 处理代码：`src/qasper_prepare.py` 和 `src/fixed_chunks.py`；Git commit 待记录。
- B1–B5 尚未运行；失败清单及完成后核验待补充。
